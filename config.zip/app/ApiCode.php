<?php

namespace App;

class ApiCode{
    public const SOMETHING_WENT_WRONG = 250;
    public const INVALID_EMAIL_VERIFICATION_URL = 254;
}