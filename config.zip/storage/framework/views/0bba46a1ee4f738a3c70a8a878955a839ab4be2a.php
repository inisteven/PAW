<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Tugas\PAW\Tubes UAS\PAW_UAS_Kel2_BE\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>