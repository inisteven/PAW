<?php echo e($slot); ?>

<?php /**PATH D:\Tugas\PAW\Tubes UAS\PAW_UAS_Kel2_BE\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>